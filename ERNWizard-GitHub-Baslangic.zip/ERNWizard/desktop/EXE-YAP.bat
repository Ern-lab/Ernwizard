@echo off
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
  echo Once Node.js kurmalisin: https://nodejs.org
  pause
  exit /b
)
call npm install
if errorlevel 1 goto hata
call npm run build
if errorlevel 1 goto hata
echo.
echo Bitti! "dist" klasorunde "ERNWizard" exe dosyasi olustu.
pause
exit /b
:hata
echo.
echo HATA olustu, yukaridaki mesaji kontrol et.
pause
