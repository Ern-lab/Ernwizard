@echo off
cd /d "%~dp0"
findstr /C:"BURAYA" package.json >nul
if not errorlevel 1 (
  echo Once package.json icindeki "BURAYA" yazan 3 degeri Partner Center ^> Urun kimligi sayfasindan alip degistir.
  echo Ayrintilar icin MAGAZA-REHBERI.txt dosyasina bak.
  pause
  exit /b
)
where npm >nul 2>nul
if errorlevel 1 (
  echo Once Node.js kurmalisin: https://nodejs.org
  pause
  exit /b
)
call npm install
if errorlevel 1 goto hata
call npx electron-builder --win appx
if errorlevel 1 goto hata
echo.
echo Bitti! "dist" klasorundeki .appx dosyasini Partner Center\x27a yukle.
pause
exit /b
:hata
echo.
echo HATA olustu, yukaridaki mesaji kontrol et.
pause
