# ERNWizard

PC parçalarını seçip uyumluluğu, darboğazı ve tahmini oyun FPS değerlerini gösteren bir PC toplama yardımcısı.
Geliştirici: Efe Erdem

## Klasörler
- `web/` : Web sitesi (Netlify bu klasörü yayınlar). `prices.csv` fiyat dosyası burada.
- `desktop/` : Windows uygulaması (Electron) ve Microsoft Store paketi. `EXE-YAP.bat` ve `MAGAZA-PAKETI-YAP.bat` burada.
- `data/` : Fiyat dosyasının kopyası ve notlar.

## Önemli notlar
- Puanlar ve FPS değerleri tahmindir, gerçek test sonucu değildir.
- Fiyatlar yaklaşık ve hızlı değişir; kaynaklar `web/prices.csv` içinde tarih ve kaynak sütunlarıyla yazılıdır.
- AMD, Intel, NVIDIA ve diğer marka adları ilgili sahiplerine aittir; bu proje bu firmalarla bağlantılı değildir.
- Marka logolu kişisel sürüm bu depoda YOKTUR (ticari kullanım ve marka riski nedeniyle).
